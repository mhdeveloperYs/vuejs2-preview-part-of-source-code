

export default {

  actionIcon: 'StarIcon',
  highlightColor: 'warning',
  data: [
    {index: 0, label: 'Home', url: '/', labelIcon: 'HomeIcon', highlightAction: false},
    {index: 1, label: 'Supervisors', url: '/kuwait-en/supervisors', labelIcon: 'UserIcon', highlightAction: false},
  ]
}

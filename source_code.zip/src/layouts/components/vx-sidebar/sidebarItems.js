/*=========================================================================================
  File Name: sidebarItems.js
  Description: Sidebar Items list. Add / Remove menu items from here.
  Structure :
          url     => router path
          name    => name to display in sidebar
          slug    => router path name
          icon    => Feather Icon component/icon name
          tag     => text to display on badge
          tagColor  => class to apply on badge element
          i18n    => Internationalization
          submenu   => submenu of current item (current item will become dropdown )
                NOTE: Submenu don't have any icon(you can add icon if u want to display)
          isDisabled  => disable sidebar item/group
  ----------------------------------------------------------------------------------------
  Item Name: MEMO - WEB APPLICATION
  Author: MH FULL STACK DEVELOPER
==========================================================================================*/

export default [
  {
    url: "/kuwait-en",
    name: "Dashboard",
    slug: "dashboard",
    icon: "HomeIcon",
  },
  {
		header: "ECOMMERCE",
		i18n: "eCommerce",
  },
  {
		url: null, // You can omit this
		name: "Shop",
		slug: "shop",
		icon: "ShoppingBagIcon",
		i18n: "Shop",
		submenu: [
			{
                url: '/page/promotion',
                name: "Promotions",
                slug: "promotions",
                i18n: "Analytics",
			},
			{
				url: '/page/shopbrand',
				name: "Shop Brand",
				slug: "shop-brand",
				i18n: "shopBrand",
            },
            {
				url: '/page/products',
				name: "Products",
				slug: "products",
				i18n: "products",
            },
            {
                url: '/page/shopinvoice',
                name: "Shop Invoice",
                slug: "shop-invoice",
                i18n: "shopInvoice",
            },
            {
                url: '/page/shopreport',
                name: "Shop Report",
                slug: "shop-report",
                i18n: "ShopReport",
            },
            {
                url: '/page/shopRec',
                name: "Shop Recycle Bin",
                slug: "shop-recycle-bin",
                i18n: "ShopRecycleBin",
            },
            {
                url: '/page/ShopArch',
                name: "Shop Archives",
                slug: "shop-archives",
                i18n: "ShopArchives",
            },
            {
                url: '/page/ShopPrd',
                name: "Shop Products Recovery",
                slug: "shop-products-recovery",
                i18n: "ShopProductsRecovery",
            },

		]
  },
    {
        url: null, // You can omit this
        name: "Brands",
        slug: "brands",
        icon: "SlackIcon",
        i18n: "brands"
    },
    {
        url: null, // You can omit this
        name: "Shop Recycle Bin",
        slug: "brands",
        icon: "RepeatIcon",
        i18n: "brands"
    },
    {
        url: null, // You can omit this
        name: "Shop Archives",
        slug: "brands",
        icon: "ArchiveIcon",
        i18n: "brands"
    },
    {
        url: null, // You can omit this
        name: "Products Recovery",
        slug: "brands",
        icon: "PocketIcon",
        i18n: "brands"
    },
  {
		header: "Invoices",
		i18n: "Invoices",
  },
    {
        url: null, // You can omit this
        name: "Order",
        slug: "order",
        icon: "ClipboardIcon",
        i18n: "order"
    },
    {
        url: null, // You can omit this
        name: "Map Tracking Order",
        slug: "map_tacking_order",
        icon: "MapIcon",
        i18n: "map_tracking_order"
    },
  {
		header: "Payments",
		i18n: "Payments",
  },
    {
        url: null, // You can omit this
        name: "Payment Options",
        slug: "brands",
        icon: "CreditCardIcon",
        i18n: "brands"
    },
    {
        url: null, // You can omit this
        name: "Delivery Charge",
        slug: "brands",
        icon: "TruckIcon",
        i18n: "brands"
    },
    {
        url: null, // You can omit this
        name: "Delivery Fee Tax",
        slug: "brands",
        icon: "HashIcon",
        i18n: "brands"
    },
    {
        header: "Financial Officer Section",
        i18n: "Payments",
    },
    {
        url: '/kuwait-en/supervisors',
        name: "Receiving money from the delivery",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "transfer money to shops",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "transfer of profits",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Financial disputes",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        header: "Rewards",
        i18n: "Payments",
    },
    {
        url: null,
        name: "Digital Currency",
        slug: "supervisor",
        icon: "DollarSignIcon",
    },
    {
        url: null,
        name: "Point",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Code Discount",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Discount",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Gift Icons",
        slug: "supervisor",
        icon: "GiftIcon",
    },
    {
        header: "Reports",
        i18n: "Payments",
    },
    {
        url: null,
        name: "Products",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Shops Reports",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        header: "The State",
        i18n: "Payments",
    },
    {
        url: null,
        name: "City / Province",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Address",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "My Location By Google Maps",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        header: "Opening",
        i18n: "Payments",
    },
    {
        url: null,
        name: "Language",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Country",
        slug: "supervisor",
        icon: "FlagIcon",
    },
    {
        header: "USERS",
        i18n: "users",
    },
    {
        url: "/kuwait-en/supervisors",
        name: "Supervisors",
        slug: "supervisor",
        icon: "UserIcon",
    },
    {
        url: null,
        name: "Admin",
        slug: "supervisor",
        icon: "UserIcon",
    },
    {
        url: null,
        name: "Financial Office",
        slug: "supervisor",
        icon: "UserIcon",
    },
    {
        url: null,
        name: "Customers",
        slug: "supervisor",
        icon: "UserIcon",
    },
    {
        url: null,
        name: "Dealer",
        slug: "supervisor",
        icon: "UserIcon",
    },
    {
        url: null,
        name: "Delivery",
        slug: "supervisor",
        icon: "UserIcon",
    },
    {
        header: "New With Top",
        i18n: "new_with_top",
    },
    {
        url: null,
        name: "Top Products",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "New Products",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "New Shop",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Similar Products",
        slug: "supervisor",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Top Customers Buy",
        slug: "supervisor",
        icon: "HomeIcon",
    },


    {
        header: "HOME",
        i18n: "home",
    },
    {
        url: null,
        name: "Ads",
        slug: "ads",
        icon: "ZapIcon",
    },
    {
        url: null,
        name: "Deal of the day",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Search Box",
        slug: "ads",
        icon: "SearchIcon",
    },
    {
        url: null,
        name: "Filter",
        slug: "ads",
        icon: "FilterIcon",
    },
    {
        url: null,
        name: "My Bag",
        slug: "ads",
        icon: "ShoppingBagIcon",
    },
    {
        url: null,
        name: "Social Links",
        slug: "ads",
        icon: "FacebookIcon",
    },


    {
        header: "LIST HOM PAGE",
        i18n: "home",
    },
    {
        url: null,
        name: "Login & Register Clients",
        slug: "login_register_clients",
        icon: "LogInIcon",
    },
    {
        url: null,
        name: "Login & Register Dealer",
        slug: "login_register_dealer",
        icon: "LogInIcon",
    },
    {
        url: null,
        name: "Login & Register Supervisors",
        slug: "login_register_supervisors",
        icon: "LogInIcon",
    },


    {
        header: "Chat Live",
        i18n: "home",
    },
    {
        url: null,
        name: "Pick Chat",
        slug: "pick_chat",
        icon: "MessageCircleIcon",
    },
    {
        url: null,
        name: "Customer care",
        slug: "customer_care",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Admin Chat",
        slug: "ads",
        icon: "MessageSquareIcon",
    },

    {
        header: "Support",
        i18n: "home",
    },
    {
        url: null,
        name: "Todo List",
        slug: "ads",
        icon: "CheckSquareIcon",
    },
    {
        url: null,
        name: "Email",
        slug: "ads",
        icon: "MailIcon",
    },
    {
        url: null,
        name: "FAQ",
        slug: "ads",
        icon: "HelpCircleIcon",
    },
    {
        url: null,
        name: "Contact Us",
        slug: "ads",
        icon: "VoicemailIcon",
    },
    {
        url: null,
        name: "About Us",
        slug: "ads",
        icon: "InfoIcon",
    },


    {
        header: "Help Service",
        i18n: "help_service",
    },
    {
        url: null,
        name: "Notifications",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Explanation",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "About Us",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Size Of Image",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Pop Up of app",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "info",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Calendar",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Views",
        slug: "ads",
        icon: "HomeIcon",
    },
    {
        url: null,
        name: "Terms and Conditions",
        slug: "ads",
        icon: "HomeIcon",
    },




    {
        header: "Evaluation",
        i18n: "evaluation",
    },



    {
        header: "Preferences",
        i18n: "evaluation",
    },




    {
        header: "Microsoft Services",
        i18n: "evaluation",
    },




]

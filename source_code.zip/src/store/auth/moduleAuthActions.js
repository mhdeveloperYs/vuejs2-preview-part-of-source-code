/*=========================================================================================
  File Name: moduleAuthActions.js
  Description: Auth Module Actions
  ----------------------------------------------------------------------------------------
  Item Name: MEMO - WEB APPLICATION
  Author: MHFullStackDeveloper
==========================================================================================*/

import firebase from 'firebase/app'
import 'firebase/auth'
import router from '@/router'
import authService from "../../auth/authService";

export default {
    loginAttempt({ dispatch }, payload) { 
        // New payload for login action
        const newPayload = {
            userDetails: payload.userDetails,
            country: payload.country,
            notify: payload.notify,
            closeAnimation: payload.closeAnimation
        };

        // Try to login
        dispatch('login', newPayload)
    },
    login({ commit, state, dispatch }, payload) {

       // console.log(payload);
       // If user is already logged in notify and exit
        //console.log(state.isUserLoggedIn());
        if (state.isUserLoggedIn()) {
            // Close animation if passed as payload
            if(payload.closeAnimation) payload.closeAnimation();

            payload.notify({
                title: 'Login Attempt',
                text: 'You are already logged in!',
                iconPack: 'feather',
                icon: 'icon-alert-circle',
                color: 'warning'
            });

            return false
        }

        // Try to login user
        authService.login(payload.userDetails)
            .then((result) => {
                const token = result.data[0].original.access_token;
                const user = result.data[0].original.user;

                commit('auth_success', {
                    token,
                    user
                });
                // Set FLAG username update required for updating username
                let isUsernameUpdateRequired = false;

                // if username is provided and updateUsername FLAG is true
                // set local username update FLAG to true
                // try to update username
                if(payload.updateUsername && payload.userDetails.username) {

                    isUsernameUpdateRequired = true;

                    dispatch('updateUsername', {
                        user: result.user,
                        username: payload.userDetails.username,
                        notify: payload.notify,
                        isReloadRequired: true
                    })
                }

                // Close animation if passed as payload
                if(payload.closeAnimation) payload.closeAnimation()

                // if username update is not required
                // just reload the page to get fresh data
                // set new user data in localstorage

                if(!isUsernameUpdateRequired) {
                    router.push(router.currentRoute.query.to || '/');
                   // console.log(result.data[0].original.user.user_type_id);
                   let guard = 'admin';
                   if (result.data[0].original.user.user_type_id == 1) {
                       guard = 'supervisor';
                   }

                   //console.log(result.data[0].original);
                     
                    commit('UPDATE_AUTHENTICATED_USER', {
                            user: result.data[0].original.user,
                            guard,
                            country: payload.country
                         })
                }
            }, (err) => {
                console.log(err);
                // Close animation if passed as payload
                if(payload.closeAnimation) payload.closeAnimation();
                payload.notify({
                    time: 2500,
                    title: 'Error',
                    text: err,
                    iconPack: 'feather',
                    icon: 'icon-alert-circle',
                    color: 'danger'
                });
            })

    },


    registerUser({dispatch}, payload) {


    },

  
    updateUsername({ commit }, payload) {
        payload.user.updateProfile({
            displayName: payload.username
        }).then(() => {

            // If username update is success
              // update in localstorage
            let newUserData = Object.assign({}, payload.user.providerData[0]);
            newUserData.displayName = payload.username;
            commit('UPDATE_AUTHENTICATED_USER', newUserData);

            // If reload is required to get fresh data after update
              // Reload current page
            if(payload.isReloadRequired) {
                router.push(router.currentRoute.query.to || '/')
            }
        }).catch((err) => {
              payload.notify({
                time: 8800,
                title: 'Error',
                text: err.message,
                iconPack: 'feather',
                icon: 'icon-alert-circle',
                color: 'danger'
            });
        })
    },
    updateAuthenticatedUser({ commit }, payload) {
        commit('UPDATE_AUTHENTICATED_USER', payload)
    }
}

/*=========================================================================================
  File Name: moduleAuthState.js
  Description: Auth Module State
  ----------------------------------------------------------------------------------------
  APP Name: MEMO - WEB APPLICATION
  Author: MH Full Stack Developer
==========================================================================================*/


import auth from "@/auth/authService";

export default {
    isUserLoggedIn: () => {
         let isAuthenticated = false;

        // get  current user
        const CurrentUser = localStorage.getItem('userInfo');

        if (auth.isAuthenticated() || CurrentUser) isAuthenticated = true;
        else isAuthenticated = false;
        
        return (isAuthenticated);
    },

}

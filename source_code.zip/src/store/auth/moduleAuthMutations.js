/*=========================================================================================
  File Name: moduleAuthMutations.js
  Description: Auth Module Mutations
  ----------------------------------------------------------------------------------------
  Item Name: MEMO - WEB APPLICATION
  Author: MH Full Stack Developer
==========================================================================================*/


export default {
	UPDATE_AUTHENTICATED_USER(state, data) {
		localStorage.setItem('userInfo', JSON.stringify(data.user));
		localStorage.setItem('userRole', data.guard);
    localStorage.setItem('country',JSON.stringify(data.country));
	},
  auth_request(state){
      state.status = 'loading'
  },
  auth_success(state, data){
      state.status = 'success'
      state.token = data.token
      state.AppActiveUser = data.user
  },
  auth_error(state){
      state.status = 'error'
  },
  logout(state){
      state.status = ''
      state.token = ''
  },
}

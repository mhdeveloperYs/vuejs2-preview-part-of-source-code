import auth0 from 'auth0-js';
import EventEmitter from 'events';
import authConfig from '../auth_config.json';
import axios from 'axios'
//import {commit} from "lodash";

// 'loggedIn' is used in other parts of application. So, Don't forget to change there also
const localStorageKey = 'loggedIn';

const tokenExpiryKey = 'tokenExpiry';
const loginEvent = 'loginEvent';

const webAuth = new auth0.WebAuth({
    domain: authConfig.domain,
    redirectUri: window.location.origin + process.env.BASE_URL + "callback",
    clientID: authConfig.clientId,
    responseType: 'id_token',
    scope: 'openid profile email'
});

class AuthService extends EventEmitter {
    idToken = null;
    profile = null;
    tokenExpiry = null;

    login(credentials){
        return new Promise((res,rej)=>{
            //commit('auth_request');
            axios.post('/auth/login', credentials)
                .then(response => {
                    const token = response.data[0].original.access_token;
                    const user = response.data[0].original.user;
                    localStorage.setItem('token', token);
                    axios.defaults.headers.common['Authorization'] = token;
                    
                    res(response);
                })
                .catch(err => {
                   //commit('auth_error');
                    localStorage.removeItem('token');
                    rej('Wrong Email / Password combination.')
                })
        })
    }
    // Handles the callback request from Auth0
    handleAuthentication() {
        return new Promise((resolve, reject) => {
            webAuth.parseHash((err, authResult) => {
                if (err) {
                    alert(err.error + '. Detailed error can be found in console.');
                    reject(err);
                } else {
                    this.localLogin(authResult);
                    resolve(authResult.idToken);
                }
            });
        });
    }

    localLogin(authResult) {
        this.idToken = authResult.idToken;
        this.profile = authResult.idTokenPayload;

        // Convert the JWT expiry time from seconds to milliseconds
        this.tokenExpiry = new Date(this.profile.exp * 1000);
        localStorage.setItem(tokenExpiryKey, this.tokenExpiry);
        localStorage.setItem(localStorageKey, 'true');
        localStorage.setItem('userInfo', JSON.stringify({
            displayName: this.profile.name,
            email: this.profile.email,
            photoURL: this.profile.picture,
            providerId: this.profile.sub.substr(0, this.profile.sub.indexOf('|')),
            uid: this.profile.sub
        }));

        this.emit(loginEvent, {
            loggedIn: true,
            profile: authResult.idTokenPayload,
            state: authResult.appState || {}
        });
    }

    renewTokens() {
        // reject can be used as parameter in promise for using reject
        return new Promise((resolve) => {
            if (localStorage.getItem(localStorageKey) !== "true") {
                // return reject("Not logged in");
            }

            webAuth.checkSession({}, (err, authResult) => {
                if (err) {
                    // reject(err);
                } else {
                    this.localLogin(authResult);
                    resolve(authResult);
                }
            });
        });
    }

    logOut() {
     localStorage.removeItem('token');
     this.token = null;
     this.$router.push('/auth/login');
    }

    isAuthenticated () {
        return (
            new Date(Date.now()) < new Date(localStorage.getItem(tokenExpiryKey)) &&
            localStorage.getItem(localStorageKey) === 'true'
        );
    }

    GetCurrentUser(){
        return new Promise((res,rej)=>{
            const token = localStorage.getItem('token');

            axios.post('/auth/me',token)
                .then(response => {
                    //console.log(response);
                    res(response);
                })
                .catch(err => {
                    rej('Wrong Email/Password combination.')
                })
        })
    }
}

export default new AuthService();

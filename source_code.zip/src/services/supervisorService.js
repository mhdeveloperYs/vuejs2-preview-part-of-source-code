import authConfig from '../auth_config.json';
import axios from 'axios'


class SupervisorService extends EventEmitter {

    // method for get all supervisors :
    get_all_supervisors () {

         return new Promise ((res,req) => {
             axios.get('/supervisor/all')
             .then(response => {
                 res(res);
             })
             .catch(err => {
                 req(err);
             })    
         })
           
    }

}

export default new SupervisorService();

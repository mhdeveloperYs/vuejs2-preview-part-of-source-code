
<template>

  <div>

  <div class="btn-change-clock flex flex-row justify-end">
    <vs-button @click="popupClock=true" radius color="primary" type="border" icon-pack="feather" icon="icon-clock"></vs-button>
  </div>
  

  <vs-table pagination max-items="3" search :data="users">

    <template slot="thead">
      <vs-th sort-key="no">No</vs-th>
      <vs-th sort-key="image">image</vs-th>
      <vs-th sort-key="name">name</vs-th>
      <vs-th sort-key="website">last login</vs-th>
      <vs-th sort-key="website">last logout</vs-th>
      <vs-th sort-key="website">status</vs-th>
      <vs-th sort-key="actions">actions</vs-th>
    </template>

    <template slot-scope="{data}">
      <vs-tr :data="tr" :key="indextr" v-for="(tr, indextr) in data">

        <vs-td :data="data[indextr].id">
          {{ data[indextr].id }}
        </vs-td>

        <vs-td :data="data[indextr].image">
          <img style="height: 40px;border-radius: 12px;" :src="'/uploads/avatars/'+data[indextr].image" alt="">
        </vs-td>

        <vs-td :data="data[indextr].name">
          {{ data[indextr].name }}
        </vs-td>

        <vs-td :data="data[indextr].login_at">
          {{ data[indextr].login_at }}
        </vs-td>

        <vs-td :data="data[indextr].logout_at">
          {{ data[indextr].logout_at }}
        </vs-td>

         <vs-td :data="data[indextr].status">
          {{ data[indextr].status }}
          <span>
            <vx-tooltip text="user online now" position="left">
              <vs-icon icon="lens" color="rgb(70, 150, 0)"></vs-icon>
            </vx-tooltip>
          </span>

        </vs-td>

        <vs-td :data="data[indextr].actions">

          <div style="float: left;" class="mr-2">
            <router-link  :to="{ name: 'supervisor_profile', params: { id: data[indextr].id }}">
            <vx-tooltip text="show profile" position="left">
              <vs-icon icon="remove_red_eye"></vs-icon>
            </vx-tooltip>
          </router-link>
          </div>
          
          <div style="float: left;" class="mr-2">
              <router-link :to="{ name: 'profile', params: { id: data[indextr].id }}">
                <vx-tooltip text="show what did he do of this supervisor" position="left">
                  <vs-icon icon="history"></vs-icon>
                </vx-tooltip>
              </router-link>
          </div>

          <div style="float: left;" class="mr-2">
              <router-link :to="{ name: 'profile', params: { id: data[indextr].id }}">
                <vx-tooltip text="edit profile" position="left">
                  <vs-icon icon="edit2"></vs-icon>
                </vx-tooltip>
              </router-link>
          </div>

        </vs-td>

      </vs-tr>
    </template>
  
  </vs-table>

   <vs-popup class="popup_date_time"  title="Date & Time" :active.sync="popupClock">

      <vs-list>
           <vs-list-item title="Use 24-hour Format" subtitle="13:00">
            <vs-switch color="success"  @change="change_time24()" v-model="clockSystem.style24hr"/>
          </vs-list-item>
          
          <vs-list-item title="Use 12-hour Format" subtitle="1:00 PM">
            <vs-switch color="success" @change="change_time12()" v-model="clockSystem.style12hr"/>
          </vs-list-item>
      </vs-list>

    </vs-popup>

  </div>

</template>

<script>
import axios from 'axios'
export default {

  data() {
    return {
      users: [],
      clockSystem: {
        style24hr: true,
        style12hr: false
      },
      locale: this.$i18n.locale,
      popupClock:false,
      
    }
  },
  methods: {
    change_time12 () {   
       this.clockSystem.style24hr = false
       this.$vs.notify({
          title:'Success',
          text:'Date and time format changed',
          color:'success'}
          )
    },
    change_time24 () {
       this.clockSystem.style12hr = false
       this.$vs.notify({
          title:'Success',
          text:'Date and time format changed',
          color:'success'})
    },

    // method for get all supervisors :
    get_all_supervisors () {
       axios.get('/supervisor')
       .then(response => {
        console.log(response.data.data);
           this.users = response.data.data
       })
       .catch(err => {
          console.log(err);
       })
    },
  },

  created() {
    this.get_all_supervisors();
  }


}
</script>
<style>
  
  .popup_date_time .vs-popup--header {
    background: white ;
    box-shadow: 1px 2px 12px -3px #ddd;
  }

  .popup_date_time .vs-popup--title h3 {
    font-size: 13px;
    font-weight: bold;
  }

</style>
<!-- =========================================================================================
    File Name: Login.vue
    Description: Login Page
    ----------------------------------------------------------------------------------------
      App Name: MEMO - WEB APPLICATION
      Author: Mh-FullStack-Developer
========================================================================================== -->


<template>
    <div class="h-screen flex w-full bg-img vx-row no-gutter items-center justify-center" id="page-login">
        <div class="vx-col sm:w-1/2 md:w-1/2 lg:w-3/4 xl:w-3/5 sm:m-0 m-4">
            <vx-card>
                <div slot="no-body" class="full-page-bg-color">
                    <div class="vx-row no-gutter justify-center items-center">

                        <!-- login image -->
                        <div class="vx-col hidden lg:block lg:w-1/2">
                            <img :src="image_login" alt="login" class="mx-auto">
                        </div>
                        <!-- ./loign image -->

                        <div class="vx-col sm:w-full md:w-full lg:w-1/2 d-theme-dark-bg">
                            <div class="p-8">

                                <!-- Login Header -->
                                <div class="vx-card__title mb-8">
                                    <h4 class="mb-4">Login</h4>
                                    <p>Welcome back, please login to your account.</p>
                                </div>
                                <!-- ./Login Header -->

                                <!-- Input Email -->
                                <vs-input
                                    v-validate="'required|email|min:3'"
                                    data-vv-validate-on="blur"
                                    name="email"
                                    icon="icon icon-user"
                                    icon-pack="feather"
                                    label-placeholder="Email"
                                    v-model="email"
                                    class="w-full no-icon-border"/>
                                <span class="text-danger text-sm">{{ errors.first('email') }}</span>
                                <!-- ./Input Email -->

                                <!-- Input Password -->
                                <vs-input
                                    data-vv-validate-on="blur"
                                    v-validate="'required|min:6|max:10'"
                                    type="password"
                                    name="password"
                                    icon="icon icon-lock"
                                    icon-pack="feather"
                                    label-placeholder="Password"
                                    v-model="password"
                                    class="w-full mt-6 no-icon-border" />
                                <span class="text-danger text-sm">{{ errors.first('password') }}</span>
                                <!-- ./Input Password -->    
                                
                                <!-- Country -->
                                <multiselect 
                                        v-model="country" 
                                        placeholder="Search County..."
                                        label="title"
                                        track-by="title"
                                        :options="options"
                                        :option-height="104"
                                        :custom-label="customLabel"
                                        :show-labels="false"
                                        class="w-full mt-6 no-icon-border">


                                    <template slot="singleLabel" slot-scope="props">
                                        <img class="option__image"  :src="props.option.img" alt="IMAGE">
                                        <span class="option__desc">
                                            <span class="option__title">{{ props.option.title }}</span>
                                        </span>
                                    </template>

                                    <template slot="option" slot-scope="props">
                                        <img class="option__image" :src="props.option.img" alt="IMAGE">
                                        <div class="option__desc">
                                            <span class="option__title">{{ props.option.title }}</span>
                                        </div>
                                    </template>

                                </multiselect>
                                <!-- ./ Country -->
                                      
                                <!-- remember me & forgot password -->
                                <div class="flex flex-wrap justify-between my-5">
                                    <vs-checkbox v-model="checkbox_remember_me" class="mb-3">Remember Me</vs-checkbox>
                                    <router-link to="/pages/forgot-password">Forgot Password?</router-link>
                                </div>
                                <!-- ./remember me & forgot password -->
                                    
                                <!-- button Login & Register -->    
                                <vs-button  type="border" @click="registerUser">Register</vs-button>
                                <vs-button class="float-right" :disabled="!validateForm" @click="login">Login</vs-button>
                                <!-- remember me & forgot password -->

                            </div>
                        </div>
                    </div>
                </div>
            </vx-card>
        </div>
    </div>
</template>

<script>

    export default {
        data() {
            return {
                country: { title: 'KUWAIT',slug: 'kuwait', img: "/uploads/images/flags/ar.png" },
                options: [
                { title: 'KUWAIT',lug: 'kuwait', img: "/uploads/images/flags/ar.png" },
                { title: 'UEA',slug:'uea', img: "/uploads/images/flags/en.png" },
              ],
                email: '',
                password: '',
                checkbox_remember_me: false,
                image_login: "/images/login.png"
            }
        },
        computed: {
            validateForm() {
                return !this.errors.any() && this.email != '' && this.password != '';
            },
        },
        methods: {

            customLabel ({ title, desc }) {
                return `${title} – ${desc}`
            },
             

            // method for login user :
            login() {
                // Loading
                this.$vs.loading();

                const payload = {
                    checkbox_remember_me: this.checkbox_remember_me,
                    userDetails: {
                        email: this.email,
                        password: this.password,
                    },
                    country: this.country,
                    notify: this.$vs.notify,
                    closeAnimation: this.$vs.loading.close
                };
                this.$store.dispatch('auth/loginAttempt', payload);
            },

            loginAuth0() {
                if (this.$store.state.auth.isUserLoggedIn()) {
                    this.notifyAlreadyLogedIn();
                    return false
                }
                this.$auth.login({target: this.$route.query.to});
            },

            // Notification If User Already Login      
            notifyAlreadyLogedIn() {
                this.$vs.notify({
                    title: 'Login Attempt',
                    text: 'You are already logged in!',
                    iconPack: 'feather',
                    icon: 'icon-alert-circle',
                    color: 'warning'
                });
            },

            // Method For Register
            registerUser() {
                if (this.$store.state.auth.isUserLoggedIn()) {
                    this.notifyAlreadyLogedIn();
                    return false;
                }
                this.$router.push('/pages/register');
            }
        }
    }
</script>

<!-- MultiSelect plugn Css file-->
<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
<style lang="scss">
    #page-login {
        .option__image  {
            width: 30px;height: 20px;margin-top: 1px;
            float:left;
        }

        .option__desc {
            font-size: 12px;
            font-weight: bold;
            margin: 0 8px;
            line-height: 1.9;
            float:left;

        }

        .vs-input--icon {
            z-index: 9 !important;
        }

        .multiselect__content-wrapper {
            z-index: 999 !important;
        }
    }
</style>
